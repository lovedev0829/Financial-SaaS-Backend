const companyRoles = [
    'issuer',
    'distributor'
]

const userRoles = [
    'superAdmin',
    'master',
    'admin',
    'user'
]

module.exports = {
    companyRoles,
    userRoles
}